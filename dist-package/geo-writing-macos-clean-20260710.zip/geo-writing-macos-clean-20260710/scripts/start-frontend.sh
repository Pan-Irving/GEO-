#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR/frontend"

if [ ! -d "node_modules" ]; then
  echo "frontend/node_modules not found. Run: cd frontend && npm install"
  exit 1
fi

npm run dev -- --host 127.0.0.1 --port 5173
