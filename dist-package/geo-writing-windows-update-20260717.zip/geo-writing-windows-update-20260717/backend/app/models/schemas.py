from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, Field


WorkflowStep = Literal[
    "materials",
    "intake",
    "matrix",
    "breakthrough",
    "brief",
    "article",
    "archive",
]

ParseMode = Literal["smart", "text_only", "full_ocr"]
ParseSource = Literal["fresh", "cache", "skipped_existing"]

STEP_ORDER: list[WorkflowStep] = [
    "materials",
    "intake",
    "matrix",
    "brief",
    "article",
    "archive",
]

STORAGE_STEPS: list[WorkflowStep] = [
    *STEP_ORDER,
    "breakthrough",
]

RUNNABLE_STEPS: list[WorkflowStep] = [
    "intake",
    "matrix",
    "brief",
    "article",
]


class StepState(BaseModel):
    status: Literal["pending", "running", "completed", "confirmed", "failed"] = "pending"
    input: dict[str, Any] = Field(default_factory=dict)
    output: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None
    confirmed_at: str | None = None
    updated_at: str = Field(default_factory=lambda: datetime.now(UTC).isoformat())


class Material(BaseModel):
    id: str
    filename: str
    stored_name: str
    content_type: str | None = None
    size: int = 0
    sha256: str | None = None
    parsed_path: str | None = None
    status: Literal["uploaded", "parsed", "failed"] = "uploaded"
    error: str | None = None
    parse_mode: ParseMode | None = None
    parser_version: str | None = None
    parse_source: ParseSource | None = None
    parsed_chars: int = 0
    ocr_pages: int = 0
    parsed_at: str | None = None


class CustomSource(BaseModel):
    id: str
    source_id: str
    source_step: Literal["custom"] = "custom"
    intent_group_id: str = ""
    intent_group: str = ""
    keyword: str = ""
    type: str
    title: str
    role: str = "用户自定义选题"
    brief_focus: str = ""
    channel: str = ""
    channels: list[str] = Field(default_factory=list)
    status: Literal["ready", "completed"] = "ready"
    created_at: str = Field(default_factory=lambda: datetime.now(UTC).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(UTC).isoformat())
    raw: dict[str, Any] = Field(default_factory=dict)


class Job(BaseModel):
    id: str
    step: WorkflowStep
    status: Literal["queued", "running", "cancelling", "cancelled", "completed", "failed"] = "queued"
    error: str | None = None
    total_count: int = 0
    completed_count: int = 0
    failed_count: int = 0
    skipped_count: int = 0
    current_item: str | None = None
    message: str | None = None
    created_at: str = Field(default_factory=lambda: datetime.now(UTC).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(UTC).isoformat())


class Project(BaseModel):
    id: str
    name: str
    created_at: str = Field(default_factory=lambda: datetime.now(UTC).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(UTC).isoformat())
    materials: list[Material] = Field(default_factory=list)
    intent_groups: list[dict[str, Any]] = Field(default_factory=list)
    custom_sources: list[CustomSource] = Field(default_factory=list)
    steps: dict[WorkflowStep, StepState] = Field(default_factory=dict)
    jobs: list[Job] = Field(default_factory=list)


class ProjectCreate(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class ParseMaterialsRequest(BaseModel):
    mode: ParseMode = "smart"
    force: bool = False


class RunStepRequest(BaseModel):
    payload: dict[str, Any] = Field(default_factory=dict)


class SkillDraftRequest(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class ApplyMatrixImportRequest(BaseModel):
    overwrite: bool = False


class CustomSourceRequest(BaseModel):
    title: str = Field(min_length=1, max_length=160)
    intent_group_id: str = Field(default="", max_length=120)
    intent_group: str = Field(default="", max_length=120)
    keyword: str = Field(default="", max_length=120)
    type: str = Field(default="", max_length=80)
    brief_focus: str = Field(default="", max_length=1000)
    channel: str = Field(default="", max_length=120)
    channels: list[str] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)


class CustomSourceBatchItem(BaseModel):
    title: str = Field(min_length=1, max_length=160)
    intent_group_id: str = Field(default="", max_length=120)
    intent_group: str = Field(default="", max_length=120)
    keyword: str = Field(default="", max_length=120)
    type: str = Field(default="", max_length=80)
    brief_focus: str = Field(default="", max_length=1000)
    channel: str = Field(default="", max_length=120)
    channels: list[str] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)


class CustomSourceBatchRequest(BaseModel):
    items: list[CustomSourceBatchItem] = Field(default_factory=list)
    titles: list[str] = Field(default_factory=list)
    type: str = Field(default="", max_length=80)
    brief_focus: str = Field(default="", max_length=1000)
    channel: str = Field(default="", max_length=120)
    channels: list[str] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)


class ConfirmStepRequest(BaseModel):
    notes: str | None = None


class IntentGroupUpdateRequest(BaseModel):
    name: str | None = Field(default=None, max_length=120)
    aliases: list[str] | None = None
    keywords: list[str] | None = None


class IntentGroupMergeRequest(BaseModel):
    source_group_ids: list[str] = Field(default_factory=list)


class UpdateItemRequest(BaseModel):
    payload: dict[str, Any] = Field(default_factory=dict)


class DeleteStepItemsRequest(BaseModel):
    ids: list[str] = Field(default_factory=list)


class HealthResponse(BaseModel):
    status: str
    model: str
    planning_model: str | None = None
    writing_model: str | None = None
    skill_available: bool
    active_skill_name: str = "内置默认规则"
    active_skill_id: str = "builtin"
    publishing_frontend_url: str = "http://127.0.0.1:5174"
